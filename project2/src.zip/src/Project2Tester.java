import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({BaseTester.class, IndexTester.class, SearchTester.class})
public class Project2Tester {
	/*
	 * To be eligible for code review for project 2, you must pass
	 * this test suite on the lab computers.
	 */
}
